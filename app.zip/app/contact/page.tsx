import type { Metadata } from "next";
import { business } from "@/data/business";

export const metadata: Metadata = {
  title: `Kontakt | ${business.name}`,
};

export default function ContactPage() {
  const mapSrc = `https://www.google.com/maps?q=${encodeURIComponent(
    business.mapEmbedQuery
  )}&output=embed`;

  return (
    <>
      <section className="relative overflow-hidden bg-crimson">
        <div className="slice-bottom container-page py-20 pb-28 md:py-28 md:pb-36">
          <p className="font-body text-sm font-semibold tracking-wide text-saffron">
            Kontakt
          </p>
          <h1 className="mt-3 max-w-2xl font-display text-4xl font-bold italic text-cream md:text-5xl">
            Wir freuen uns auf dich
          </h1>
        </div>
      </section>

      <section className="container-page grid gap-12 py-16 lg:grid-cols-2">
        <div>
          <h2 className="font-display text-2xl font-bold text-ink">
            Schreib uns
          </h2>
          <p className="mt-2 text-sm text-ink/60">
            Fragen, Feedback oder eine größere Bestellung? Nutze das
            Formular oder ruf direkt an.
          </p>

          <form className="mt-8 space-y-5" action={`mailto:${business.email}`} method="POST" encType="text/plain">
            <div>
              <label htmlFor="name" className="block font-body text-sm font-medium text-ink">
                Name
              </label>
              <input
                id="name"
                name="name"
                type="text"
                required
                className="mt-1 w-full rounded-sm border border-ink/20 bg-white px-4 py-2.5 font-body text-ink focus:border-crimson"
              />
            </div>
            <div>
              <label htmlFor="email" className="block font-body text-sm font-medium text-ink">
                E-Mail
              </label>
              <input
                id="email"
                name="email"
                type="email"
                required
                className="mt-1 w-full rounded-sm border border-ink/20 bg-white px-4 py-2.5 font-body text-ink focus:border-crimson"
              />
            </div>
            <div>
              <label htmlFor="message" className="block font-body text-sm font-medium text-ink">
                Nachricht
              </label>
              <textarea
                id="message"
                name="message"
                rows={5}
                required
                className="mt-1 w-full rounded-sm border border-ink/20 bg-white px-4 py-2.5 font-body text-ink focus:border-crimson"
              />
            </div>
            <button
              type="submit"
              className="rounded-sm bg-crimson px-6 py-3 font-body font-semibold text-cream transition-transform hover:scale-105"
            >
              Nachricht senden
            </button>
          </form>
        </div>

        <div>
          <div className="overflow-hidden rounded-sm border border-ink/10">
            <iframe
              title="Standort Kösem Food House"
              src={mapSrc}
              width="100%"
              height="320"
              loading="lazy"
              style={{ border: 0 }}
            />
          </div>

          <div className="mt-8 grid gap-6 sm:grid-cols-2">
            <div>
              <h3 className="font-body text-sm font-semibold uppercase tracking-wide text-crimson">
                Adresse
              </h3>
              <p className="mt-2 text-ink/75">
                {business.address.street}
                <br />
                {business.address.zipCity}
              </p>
            </div>
            <div>
              <h3 className="font-body text-sm font-semibold uppercase tracking-wide text-crimson">
                Kontakt
              </h3>
              <p className="mt-2 text-ink/75">
                <a href={business.phoneHref} className="hover:text-crimson">
                  {business.phone}
                </a>
                <br />
                <a href={`mailto:${business.email}`} className="hover:text-crimson">
                  {business.email}
                </a>
              </p>
            </div>
          </div>

          <div className="mt-6">
            <h3 className="font-body text-sm font-semibold uppercase tracking-wide text-crimson">
              Öffnungszeiten
            </h3>
            <ul className="mt-2 space-y-1 text-ink/75">
              {business.hours.map((h) => (
                <li key={h.day} className="flex justify-between gap-6 border-b border-ink/5 py-1 text-sm">
                  <span>{h.day}</span>
                  <span className={h.time === "Geschlossen" ? "text-ink/40" : ""}>
                    {h.time}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>
    </>
  );
}
