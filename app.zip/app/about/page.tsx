import type { Metadata } from "next";
import PhotoSlot from "@/components/PhotoSlot";
import { business } from "@/data/business";

export const metadata: Metadata = {
  title: `Über uns | ${business.name}`,
};

const values = [
  {
    title: "Handwerk",
    text: "Jeder Spieß wird von Hand gewürzt und geschichtet — keine Fertigware.",
  },
  {
    title: "Herkunft",
    text: "Rezepte, die seit Generationen in der Familie weitergegeben werden.",
  },
  {
    title: "Nachbarschaft",
    text: "Ein Ort zum Ankommen, mitten in Schweinfurt.",
  },
];

export default function AboutPage() {
  return (
    <>
      <section className="relative overflow-hidden bg-crimson">
        <div className="slice-bottom container-page py-20 pb-28 md:py-28 md:pb-36">
          <p className="font-body text-sm font-semibold tracking-wide text-saffron">
            Über uns
          </p>
          <h1 className="mt-3 max-w-2xl font-display text-4xl font-bold italic text-cream md:text-5xl">
            Vom Familienrezept auf den Teller in Schweinfurt
          </h1>
        </div>
      </section>

      <section className="container-page grid gap-12 py-20 md:grid-cols-2 md:items-center">
        <PhotoSlot label="Foto: Team / Küche" className="aspect-[4/3] w-full" />
        <div>
          <h2 className="font-display text-3xl font-bold text-ink">
            Unsere Geschichte
          </h2>
          <p className="mt-4 text-ink/70">
            {business.name} wurde gegründet, um Schweinfurt herzhaften,
            ehrlichen türkischen Geschmack zu bringen. Der Döner wird bei uns
            noch von Hand gewürzt und auf dem Spieß geschichtet, die Soßen
            werden täglich frisch angerührt und Lahmacun sowie Pide kommen
            direkt aus dem Steinofen.
          </p>
          <p className="mt-4 text-ink/70">
            Egal ob schnelle Mittagspause, Treffen mit Freunden oder Essen
            zum Mitnehmen — bei uns steht Qualität immer vor Tempo.
          </p>
        </div>
      </section>

      <section className="relative bg-ink">
        <div className="slice-both py-20 text-cream">
          <div className="container-page">
            <h2 className="font-display text-3xl font-bold italic md:text-4xl">
              Was uns wichtig ist
            </h2>
            <div className="mt-10 grid gap-8 md:grid-cols-3">
              {values.map((v) => (
                <div key={v.title} className="border-t-4 border-saffron pt-4">
                  <h3 className="font-display text-xl font-semibold">
                    {v.title}
                  </h3>
                  <p className="mt-2 text-sm text-cream/70">{v.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
