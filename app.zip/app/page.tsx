import Link from "next/link";
import PhotoSlot from "@/components/PhotoSlot";
import MenuRow from "@/components/MenuRow";
import { business, menu } from "@/data/business";

const features = [
  {
    title: "Täglich frisch",
    text: "Der Spieß wird jeden Morgen neu vorbereitet, nichts liegt vom Vortag.",
  },
  {
    title: "Hausgemachte Soßen",
    text: "Knoblauch-, Kräuter- und Scharfsoße werden bei uns selbst angerührt.",
  },
  {
    title: "Steinofenbrot",
    text: "Lahmacun und Pide kommen frisch gebacken aus dem Steinofen.",
  },
  {
    title: "Schnell & herzlich",
    text: "Mittagspause oder Feierabend — wir sind für dich da.",
  },
];

const testimonials = [
  {
    quote:
      "Der beste Döner in Schweinfurt, ganz klar. Frisch, würzig, faire Preise.",
    author: "Stammgast aus der Innenstadt",
  },
  {
    quote:
      "Lahmacun schmeckt wie bei meiner Großmutter. Komme jede Woche vorbei.",
    author: "THWS-Student",
  },
  {
    quote: "Freundliches Team und man merkt, dass hier mit Liebe gekocht wird.",
    author: "Nachbarschaft Ignaz-Schön-Straße",
  },
];

export default function HomePage() {
  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden bg-crimson">
        <div className="slice-bottom relative bg-crimson pb-24 pt-16 md:pb-32 md:pt-24">
          <div className="container-page grid items-center gap-10 md:grid-cols-2">
            <div>
              <p className="font-body text-sm font-semibold tracking-wide text-saffron">
                Schweinfurt · Ignaz-Schön-Straße 42
              </p>
              <h1 className="mt-3 font-display text-5xl font-bold italic leading-[1.05] text-cream md:text-6xl">
                Frisch vom Spieß, mit Herz serviert.
              </h1>
              <p className="mt-5 max-w-md font-body text-cream/85">
                {business.name} bringt herzhaften türkischen Geschmack nach
                Schweinfurt — Döner, Dürüm und Lahmacun, jeden Tag frisch
                zubereitet.
              </p>
              <div className="mt-8 flex flex-wrap gap-4">
                <Link
                  href="/menu"
                  className="rounded-sm bg-saffron px-6 py-3 font-body font-semibold text-ink transition-transform hover:scale-105"
                >
                  Speisekarte ansehen
                </Link>
                <Link
                  href="/contact"
                  className="rounded-sm border border-cream/40 px-6 py-3 font-body font-semibold text-cream transition-colors hover:border-saffron hover:text-saffron"
                >
                  Anfahrt & Kontakt
                </Link>
              </div>
            </div>
            <PhotoSlot
              label="Hero-Foto: frisch geschnittener Döner"
              className="aspect-[4/3] w-full"
            />
          </div>
        </div>
      </section>

      {/* QUALITY / FEATURES */}
      <section className="container-page py-20">
        <div className="max-w-xl">
          <p className="font-body text-sm font-semibold uppercase tracking-wide text-crimson">
            Worauf wir stolz sind
          </p>
          <h2 className="mt-2 font-display text-3xl font-bold text-ink md:text-4xl">
            Qualität, die man schmeckt
          </h2>
        </div>
        <div className="mt-10 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((f) => (
            <div key={f.title} className="border-t-4 border-saffron pt-4">
              <h3 className="font-display text-xl font-semibold text-ink">
                {f.title}
              </h3>
              <p className="mt-2 text-sm text-ink/65">{f.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* MENU PREVIEW */}
      <section className="relative bg-cream">
        <div className="slice-both bg-ink py-20 text-cream">
          <div className="container-page grid gap-12 lg:grid-cols-2">
            <div>
              <p className="font-body text-sm font-semibold uppercase tracking-wide text-saffron">
                Speisekarte
              </p>
              <h2 className="mt-2 font-display text-3xl font-bold italic md:text-4xl">
                Unsere Klassiker
              </h2>
              <p className="mt-4 max-w-sm text-cream/70">
                Eine kleine Auswahl unserer Speisekarte — die komplette Karte
                mit allen Kategorien findest du hier.
              </p>
              <Link
                href="/menu"
                className="mt-6 inline-block rounded-sm bg-saffron px-6 py-3 font-body font-semibold text-ink transition-transform hover:scale-105"
              >
                Ganze Speisekarte
              </Link>
            </div>
            <div className="rounded-sm bg-cream px-6 py-6 text-ink md:px-8 md:py-8">
              {menu[0].items.slice(0, 4).map((item) => (
                <MenuRow key={item.name} item={item} />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="container-page py-20">
        <div className="max-w-xl">
          <p className="font-body text-sm font-semibold uppercase tracking-wide text-crimson">
            Was Gäste sagen
          </p>
          <h2 className="mt-2 font-display text-3xl font-bold text-ink md:text-4xl">
            Stimmen aus der Nachbarschaft
          </h2>
        </div>
        <div className="mt-10 grid gap-8 md:grid-cols-3">
          {testimonials.map((t) => (
            <figure
              key={t.author}
              className="flex flex-col justify-between rounded-sm bg-white/60 p-6"
            >
              <blockquote className="font-display text-lg italic leading-relaxed text-ink">
                „{t.quote}"
              </blockquote>
              <figcaption className="mt-4 text-sm font-medium text-crimson">
                {t.author}
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      {/* LOCATION TEASER */}
      <section className="relative overflow-hidden bg-saffron">
        <div className="slice-top container-page grid gap-10 py-20 pt-24 md:grid-cols-2 md:items-center">
          <div>
            <h2 className="font-display text-3xl font-bold text-ink md:text-4xl">
              Komm vorbei
            </h2>
            <p className="mt-4 max-w-sm text-ink/75">
              {business.address.street}, {business.address.zipCity}
              <br />
              Montag – Freitag 11:00 – 20:00 · Samstag 11:00 – 18:00
            </p>
            <a
              href={business.phoneHref}
              className="mt-6 inline-block rounded-sm bg-ink px-6 py-3 font-body font-semibold text-cream transition-transform hover:scale-105"
            >
              {business.phone}
            </a>
          </div>
          <PhotoSlot label="Foto: Ladenfront / Innenraum" className="aspect-video w-full" />
        </div>
      </section>
    </>
  );
}
