import type { Metadata } from "next";
import PhotoSlot from "@/components/PhotoSlot";
import { business } from "@/data/business";

export const metadata: Metadata = {
  title: `Galerie | ${business.name}`,
};

const slots = [
  "Döner vom Spieß",
  "Lahmacun im Ofen",
  "Ladenfront",
  "Innenraum",
  "Zubereitung",
  "Team bei der Arbeit",
  "Dürüm frisch gerollt",
  "Beilagen & Salate",
];

export default function GalleryPage() {
  return (
    <>
      <section className="relative overflow-hidden bg-crimson">
        <div className="slice-bottom container-page py-20 pb-28 md:py-28 md:pb-36">
          <p className="font-body text-sm font-semibold tracking-wide text-saffron">
            Galerie
          </p>
          <h1 className="mt-3 max-w-2xl font-display text-4xl font-bold italic text-cream md:text-5xl">
            Ein Blick in unsere Küche
          </h1>
        </div>
      </section>

      <section className="container-page py-16">
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {slots.map((label, i) => (
            <PhotoSlot
              key={label}
              label={label}
              className={`aspect-square w-full ${
                i % 5 === 0 ? "md:col-span-2 md:row-span-2 md:aspect-auto" : ""
              }`}
            />
          ))}
        </div>
        <p className="mt-8 text-sm text-ink/50">
          Platzhalter-Raster — sobald Fotos von {business.name} vorliegen,
          ersetzen wir diese Kacheln durch echte Aufnahmen.
        </p>
      </section>
    </>
  );
}
