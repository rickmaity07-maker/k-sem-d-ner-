import type { Metadata } from "next";
import MenuRow from "@/components/MenuRow";
import { business, menu } from "@/data/business";

export const metadata: Metadata = {
  title: `Speisekarte | ${business.name}`,
};

export default function MenuPage() {
  return (
    <>
      <section className="relative overflow-hidden bg-crimson">
        <div className="slice-bottom container-page py-20 pb-28 md:py-28 md:pb-36">
          <p className="font-body text-sm font-semibold tracking-wide text-saffron">
            Speisekarte
          </p>
          <h1 className="mt-3 max-w-2xl font-display text-4xl font-bold italic text-cream md:text-5xl">
            Frisch, würzig, hausgemacht
          </h1>
          <p className="mt-4 max-w-md text-cream/80">
            Preise vorbehaltlich Änderungen. Bei Allergien oder Unverträglichkeiten
            sprich uns gerne an.
          </p>
        </div>
      </section>

      <section className="container-page py-16">
        {/* Category jump links */}
        <nav
          aria-label="Kategorien"
          className="mb-12 flex flex-wrap gap-3 border-b border-ink/10 pb-8"
        >
          {menu.map((cat) => (
            <a
              key={cat.id}
              href={`#${cat.id}`}
              className="rounded-full border border-crimson/30 px-4 py-1.5 font-body text-sm font-medium text-crimson transition-colors hover:bg-crimson hover:text-cream"
            >
              {cat.title}
            </a>
          ))}
        </nav>

        <div className="grid gap-16 lg:grid-cols-2">
          {menu.map((cat) => (
            <div key={cat.id} id={cat.id} className="scroll-mt-24">
              <h2 className="font-display text-2xl font-bold text-ink">
                {cat.title}
              </h2>
              {cat.subtitle && (
                <p className="mt-1 text-sm text-ink/55">{cat.subtitle}</p>
              )}
              <div className="mt-4 divide-y divide-ink/10">
                {cat.items.map((item) => (
                  <MenuRow key={item.name} item={item} />
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
